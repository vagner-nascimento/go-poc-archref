package main

import (
	"github.com/vagner-nascimento/go-poc-archref/src/loader"
)

func keepUp() {
	<-make(chan bool)
}

func main() {
	if err := loader.LoadApplication(); err != nil {
		panic(err)
	}
	keepUp()
}
