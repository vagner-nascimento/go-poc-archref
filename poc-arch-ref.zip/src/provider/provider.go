package provider

import (
	"github.com/vagner-nascimento/go-poc-archref/src/app"
	"github.com/vagner-nascimento/go-poc-archref/src/infra/repository"
	"github.com/vagner-nascimento/go-poc-archref/src/integration"
	"sync"
)

var resources struct {
	customerUseCase app.CustomerUseCase
}

var once struct {
	customerUs sync.Once
}

func CustomerUseCase() app.CustomerUseCase {
	once.customerUs.Do(func() {
		resources.customerUseCase = app.NewCustomerUseCase(repository.NewCustomerRepository())
	})
	return resources.customerUseCase
}

func AmqpSubscription() integration.AmqpSubscriptionHandler {
	return repository.NewAmqpSubscription()
}
