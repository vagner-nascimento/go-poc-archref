package integration

import (
	"github.com/vagner-nascimento/go-poc-archref/config"
)

type userConsumer struct {
	topic    string
	consumer string
	handler  func([]byte)
}

func (uc *userConsumer) GetTopic() string {
	return uc.topic
}

func (uc *userConsumer) GetConsumer() string {
	return uc.consumer
}

func (uc *userConsumer) GetHandler() func([]byte) {
	return uc.handler
}

func newUserConsumer(handler func(data []byte)) AmqpConsumer {
	c := config.Get().Integration.Amqp.Subs.User
	return &userConsumer{
		topic:    c.Topic,
		consumer: c.Consumer,
		handler:  handler,
	}
}
