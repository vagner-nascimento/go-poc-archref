package integration

import (
	"fmt"
	"github.com/vagner-nascimento/go-poc-archref/config"
	"github.com/vagner-nascimento/go-poc-archref/src/infra"
	"github.com/vagner-nascimento/go-poc-archref/src/model"
	"github.com/vagner-nascimento/go-poc-archref/src/provider"
)

type AmqpSubscriptionHandler interface {
	AddSubscriber(topicName string, consumerName string, messageHandler func(data []byte)) error
	SubscribeAll() error
}

// TODO: Realise better way to get this data handler
func consumerDataHandler(data []byte) {
	if user, err := model.NewUserFromJsonBytes(data); err == nil {
		customerUs := provider.CustomerUseCase()
		_, err = customerUs.UpdateFromUser(user)
	} else {
		infra.LogError("error on update a customer", err)
	}
}

// TODO: FIX CIRCLE REFERENCE
func GetAmqpConsumers() error {
	subscription := provider.AmqpSubscription()
	subs := config.Get().Integration.Amqp.Subs // TODO: Add more consumers to test
	if err := subscription.AddSubscriber(subs.User.Topic, subs.User.Consumer, consumerDataHandler); err != nil {
		infra.LogInfo(fmt.Sprintf("cannot subscribe User. config topic: %s, config consumer: %s, handler is nil: %s",
			subs.User.Topic,
			subs.User.Consumer,
			consumerDataHandler == nil))
	}
	return subscription.SubscribeAll()
}
