package repository

import (
	"errors"
	"github.com/vagner-nascimento/go-poc-archref/src/infra/data"
	"github.com/vagner-nascimento/go-poc-archref/src/integration"
)

type rabbitSubscription struct {
	subscribers []data.AmqSubscriber
}

func (rs *rabbitSubscription) AddSubscriber(topicName string, consumerName string, messageHandler func(data []byte)) error {
	if topicName == "" || consumerName == "" || messageHandler == nil {
		return errors.New("invalid subscriber")
	}
	rs.subscribers = append(rs.subscribers, data.NewAmqpSubscriber(topicName, consumerName, messageHandler))
	return nil
}

func (rs *rabbitSubscription) SubscribeAll() (err error) {
	if len(rs.subscribers) > 0 {
		err = data.SubscribeConsumers(rs.subscribers)
	} else {
		err = errors.New("there are no subscribers to consume topics")
	}
	return err
}

func NewAmqpSubscription() integration.AmqpSubscriptionHandler {
	return &rabbitSubscription{}
}
